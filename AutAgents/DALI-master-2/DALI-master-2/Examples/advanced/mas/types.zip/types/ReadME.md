In this folder all the agent types shall exists as DALI sources. From these files all of agent instances will be forked from the same type, sharing the same DALI code.
